package com.example.inheritancecalculator;



import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText editText;
    EditText editText1;
    EditText editText2;
    TextView textView;
    TextView textView1;

    Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText =findViewById(R.id.son);
        editText1 =findViewById(R.id.daughter);
        editText2 =findViewById(R.id.land);
        textView =findViewById(R.id.screen);
        button = findViewById(R.id.calculate);
        textView1 =findViewById(R.id.screen1);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String url = editText.getText().toString();
                String url1 = editText1.getText().toString();
                String url2 = editText2.getText().toString();
                float i = Float.parseFloat(url);
                float j= Float.parseFloat(url1);
                float k= Float.parseFloat(url2);
                float n = j/2;
                float sum = i+n;
                float l = k/sum;
                float r = l;
                float m = r/2;


                textView.setText(Float.toString(r));
                textView1.setText(Float.toString(m));






            }
        });






    }
}
